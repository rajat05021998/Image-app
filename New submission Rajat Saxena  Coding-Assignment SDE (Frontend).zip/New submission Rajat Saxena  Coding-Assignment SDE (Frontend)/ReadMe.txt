Important Points:-

1- This Project has been made primarily in React JS , I have used Unsplash API .
2- I have written the code in ReactJS (as I am more comfortable in it and have worked on it previously) , the same code can be remodelled for NestJS if required .
3- I have compiled the code on my local machine but could not host the project live due to time constraints .

The below are the steps that I followed for running the code on my local machine :-

In the project directory, first I ran:

1- npm start
It will run the app in the development mode.
Open http://localhost:3000 to view it in the browser.

The page will reload if you make edits.

2- npm test
Launches the test runner in the interactive watch mode.

3- npm run build
Builds the app for production to the build folder.
It correctly bundles React in production mode and optimizes the build for the best performance.

Now the app is ready to be deployed .